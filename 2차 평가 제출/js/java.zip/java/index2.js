$(function() {

    $('.in2').css({
        color:'red',
        fontsize:'60px',
        

    });
  
    var count0 =14999500;
    var size=58; 
    var in2=$(".in2");

  
    timeCounter();
  
    function timeCounter() {
  
      id0 = setInterval(count0Fn, 4);
  
      function count0Fn() {
        count0++;
        
        if (count0 ==15000001) {
          clearInterval(id0);
          size++;
          in2.css("font-size",size+"px");
          
        } else {
          $(".in2").eq(0).text(count0);
         
        }
  
      }
  

    }
  });